# Vinit ISRO Course Tracker

Ready to deploy app on GitHub Pages.

### How to deploy:
1. Go to GitHub → Open your repo → Upload these files.
2. Go to Settings → Pages
3. Source: main branch, root folder → Save.
4. App will go live at:  
   `https://vinitrajput13.github.io/vinit-isro-tracker/`
